namespace GardenSimulator {
    export enum CropType {
        PUMPKIN,
        TOMATO,
        SUNFLOWER,
        SALAD,
        STRAWBERRY,
    }
}
