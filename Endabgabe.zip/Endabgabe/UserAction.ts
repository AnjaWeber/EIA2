namespace GardenSimulator {
    export enum UserAction {
        PLANT,
        WATER,
        FERTILIZE,
        FIGHT_PEST,
        HARVEST,
    }
}
